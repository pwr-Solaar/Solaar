#
#
#

from __future__ import absolute_import, division, print_function, unicode_literals

__version__ = '0.8.9.4'
NAME = 'Solaar'
